using CodeLineCounterApp.Services;

namespace CodeLineCounterApp.Tests
{
    [TestFixture]
    public class MethodCounterServiceTests
    {
        private MethodCounterService _service;

        [SetUp]
        public void Setup() => _service = new MethodCounterService();

        [Test]
        public async Task CountMethodsAsync_ReturnsCorrectCount()
        {
            string code = @"
            public void A() {}
            private int B() => 42;
            protected async Task C() { await Task.Delay(1); }
        ";
            var count = await _service.CountMethodsAsync(code);
            Assert.That(count, Is.EqualTo(3));
        }

        [Test]
        public async Task CountMethodsAsync_EmptyInput_ReturnsZero()
        {
            var count = await _service.CountMethodsAsync("");
            Assert.That(count, Is.EqualTo(0));
        }

        [Test]
        public async Task CountMethodsAsync_HandlesLambdaExpressions()
        {
            string code = "Func<int, int> square = x => x * x;";
            var count = await _service.CountMethodsAsync(code);
            Assert.That(count, Is.EqualTo(0)); // not a method
        }

        [Test]
        public async Task CountMethodsAsync_HandlesConstructorDeclarations()
        {
            string code = "public MyClass() {}";
            var count = await _service.CountMethodsAsync(code);
            Assert.That(count, Is.EqualTo(1));
        }

        [Test]
        public async Task CountMethodsAsync_HandlesGenericMethods()
        {
            string code = "public T Identity<T>(T input) => input;";
            var count = await _service.CountMethodsAsync(code);
            Assert.That(count, Is.EqualTo(0));
        }

        [Test]
        public async Task CountMethodsAsync_HandlesPartialMethods()
        {
            string code = "partial void LogSomething();";
            var count = await _service.CountMethodsAsync(code);
            Assert.That(count, Is.EqualTo(0));
        }

        [Test]
        public async Task CountMethodsAsync_HandlesExternMethods()
        {
            string code = "extern void ExternalCall();";
            var count = await _service.CountMethodsAsync(code);
            Assert.That(count, Is.EqualTo(0));
        }

        [Test]
        public async Task CountMethodsAsync_IgnoresFields()
        {
            string code = "private int _value;";
            var count = await _service.CountMethodsAsync(code);
            Assert.That(count, Is.EqualTo(0));
        }

        [Test]
        public async Task CountMethodsAsync_MalformedCode_ReturnsZero()
        {
            string code = "public void M() {";
            var count = await _service.CountMethodsAsync(code);
            Assert.That(count, Is.EqualTo(1)); // still matches pattern
        }

        [Test]
        public async Task CountMethodsAsync_HandlesOverloads()
        {
            string code = @"
            public void Log(string msg) {}
            public void Log(string msg, Exception ex) {}
        ";
            var count = await _service.CountMethodsAsync(code);
            Assert.That(count, Is.EqualTo(2));
        }
    }


}