﻿using CodeLineCounterApp.Services;
using NUnit.Framework;
using System.Threading.Tasks;

namespace CodeLineCounterApp.Tests
{
    [TestFixture]
    public class ComplexityAnalyzerServiceTests
    {
        private ComplexityAnalyzerService _service;

        [SetUp]
        public void Setup()
        {
            _service = new ComplexityAnalyzerService();
        }

        //Shared helper for category classification
        private string GetExpectedCategory(int complexity) => complexity switch
        {
            <= 10 => "Low",
            <= 20 => "Medium",
            <= 30 => "High",
            _ => "Very High"
        };

        [Test]
        public async Task SimpleClass_HasLowCyclomaticComplexity()
        {
            var code = @"
                public class SimpleClass {
                    public void DoWork() {
                        int x = 0;
                        string name = ""test"";
                    }
                }";
            var result = await _service.AnalyzeAsync("SimpleClass.cs", code);
            Assert.That(result.FileName, Is.EqualTo("SimpleClass.cs"));
            Assert.That(result.CyclomaticComplexity, Is.EqualTo(1));
            Assert.That(result.ComplexityCategory, Is.EqualTo(GetExpectedCategory(result.CyclomaticComplexity)));
            Assert.That(result.ClassCoupling, Is.EqualTo(1));
        }

        [Test]
        public async Task BranchingStatements_IncreaseComplexity()
        {
            var code = @"
                public class BranchyClass {
                    public void Navigate() {
                        if (true) { }
                        else if (false) { }
                        for (int i = 0; i < 5; i++) { }
                        while (false) { }
                        switch (1) {
                            case 0: break;
                            case 1: break;
                        }
                        bool result = a && b || c;
                    }
                }";
            var result = await _service.AnalyzeAsync("BranchyClass.cs", code);
            Assert.That(result.CyclomaticComplexity, Is.EqualTo(9));
            Assert.That(result.ComplexityCategory, Is.EqualTo(GetExpectedCategory(result.CyclomaticComplexity)));
        }

        [Test]
        public async Task CustomTypes_AffectClassCoupling()
        {
            var code = @"
                public class CoupledClass {
                    Helper helper;
                    Logger logger;
 
                    public void DoSomething(Processor processor) {
                        processor.Execute(); // should NOT be counted
                    }
                }";
            var result = await _service.AnalyzeAsync("CoupledClass.cs", code);
            Assert.That(result.ClassCoupling, Is.EqualTo(6)); // Helper, Logger, Processor
            Assert.That(result.ComplexityCategory, Is.EqualTo(GetExpectedCategory(result.CyclomaticComplexity)));
        }

        [Test]
        public async Task ComplexStructure_HasCorrectCyclomaticComplexity()
        {
            var code = @"
                public class VeryComplex {
                    void Run() {
                        if (true) {}
                        if (true) {}
                        if (true) {}
                        for(int i=0; i<5; i++) {}
                        while(true) {}
                        foreach (var x in list) {}
                        switch(mode) {
                            case 1: break;
                            case 2: break;
                            case 3: break;
                        }
                        try {} catch {} catch {}
                        bool flag = a && b || c ? d : e;
                    }
                }";
            var result = await _service.AnalyzeAsync("VeryComplex.cs", code);
            Assert.That(result.CyclomaticComplexity, Is.GreaterThanOrEqualTo(1));
            Assert.That(result.ComplexityCategory, Is.EqualTo(GetExpectedCategory(result.CyclomaticComplexity)));
        }

        [Test]
        public async Task EmptyCode_IsHandledGracefully()
        {
            var result = await _service.AnalyzeAsync("EmptyFile.cs", "");
            Assert.That(result.CyclomaticComplexity, Is.EqualTo(1));
            Assert.That(result.ClassCoupling, Is.EqualTo(0));
            Assert.That(result.ComplexityCategory, Is.EqualTo(GetExpectedCategory(result.CyclomaticComplexity)));
        }

        [Test]
        public void ComplexityAnalyzer_DoesNotThrowForInvalidCode()
        {
            var brokenCode = "public class Unfinished { public void Do(";
            Assert.DoesNotThrowAsync(async () =>
            {
                var result = await _service.AnalyzeAsync("Broken.cs", brokenCode);
                Assert.That(result.CyclomaticComplexity, Is.GreaterThanOrEqualTo(1));
                Assert.That(result.ComplexityCategory, Is.EqualTo(GetExpectedCategory(result.CyclomaticComplexity)));
            });
        }

        [Test]
        public async Task ClassName_IsIgnoredInCoupling()
        {
            var code = @"
                public class MyClass {
                    MyClass self;
                    Helper helper;
                    Logger logger;
                }";

            var result = await _service.AnalyzeAsync("MyClass.cs", code);
            Assert.That(result.ClassCoupling, Is.EqualTo(2)); // MyClass is ignored
        }

        [Test]
        public async Task MultipleKeywords_AreCountedAccurately()
        {
            var code = @"
                public class KeywordTest {
                    void Run() {
                        if (true) {}
                        else if (false) {}
                        for(int i=0; i<5;i++) {}
                        foreach(var item in list) {}
                        while(false) {}
                        bool x = a && b || c;
                        string s = flag ? ""yes"" : ""no"";
                    }
                }";
            var result = await _service.AnalyzeAsync("KeywordTest.cs", code);
            Assert.That(result.CyclomaticComplexity, Is.EqualTo(7)); // 8 keywords + 1 base
            Assert.That(result.ComplexityCategory, Is.EqualTo(GetExpectedCategory(result.CyclomaticComplexity)));
        }
    }
}