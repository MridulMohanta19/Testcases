﻿using CodeLineCounterApp.Contracts;
using CodeLineCounterApp.Models;
using CodeLineCounterApp.Services;
using Moq;
using NUnit.Framework;

namespace CodeLineCounterApp.Tests
{
    [TestFixture]
    public class FileAnalyzerServiceTests
    {
        private Mock<ILineCounter> _lineCounterMock;
        private Mock<IMethodCounter> _methodCounterMock;
        private Mock<ILoggerService> _loggerMock;
        private FileAnalyzerService _service;
        private Mock<IComplexityAnalyzer> _complexityAnalyzerMock;


        [SetUp]
        public void Setup()
        {
            _lineCounterMock = new Mock<ILineCounter>();
            _methodCounterMock = new Mock<IMethodCounter>();
            _complexityAnalyzerMock = new Mock<IComplexityAnalyzer>();
            _loggerMock = new Mock<ILoggerService>();

            _service = new FileAnalyzerService(
                _lineCounterMock.Object,
                _methodCounterMock.Object,
                _complexityAnalyzerMock.Object,
                _loggerMock.Object);
        }


        //[Test]
        //public async Task AnalyzeFilesAsync_ReturnsExpectedResults()
        //{
        //    var tempFile = Path.Combine(Path.GetTempPath(), $"test_{Guid.NewGuid()}.cs");

        //    // Create and release the file
        //    await File.WriteAllTextAsync(tempFile, "public void Test() {}");

        //    // Wait briefly to ensure OS releases the lock
        //    await Task.Delay(100);

        //    _lineCounterMock.Setup(x => x.CountLinesAsync(tempFile)).ReturnsAsync(1);
        //    _methodCounterMock.Setup(x => x.CountMethodsAsync(It.IsAny<string>())).ReturnsAsync(1);

        //    var settings = new LoadConfigdto
        //    {
        //        IncludedExtensions = new List<string> { ".cs" },
        //        ExcludedPaths = new List<string>()
        //    };

        //    var results = await _service.AnalyzeFilesAsync(settings, Path.GetDirectoryName(tempFile), false);

        //    Assert.That(results.Count, Is.EqualTo(1));
        //    Assert.That(results[0].LineCount, Is.EqualTo(1));
        //    Assert.That(results[0].MethodCount, Is.EqualTo(1));

        //    File.Delete(tempFile);
        //}

    }

}
