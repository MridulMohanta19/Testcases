﻿using CodeLineCounterApp.Services;
using Microsoft.Extensions.Configuration;
using Serilog;

namespace CodeLineCounterApp.Tests
{
    [TestFixture]
    public class SerilogLoggerServiceTests
    {
        private SerilogLoggerService _logger;

        [SetUp]
        public void Setup()
        {
            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string>
                {
                    ["Logging:Path"] = "logs/testlog.txt"
                }).Build();

            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .WriteTo.Console()
                .WriteTo.File("logs/testlog.txt", rollingInterval: RollingInterval.Day)
                .CreateLogger();

            _logger = new SerilogLoggerService();
        }

        [Test]
        public void LogInfo_FormatsMessageCorrectly()
        {
            Assert.DoesNotThrow(() => _logger.LogInfo("Info message {0}", 42));
        }

        [Test]
        public void LogError_HandlesException()
        {
            Assert.DoesNotThrow(() => _logger.LogError("Error occurred: {0}", new Exception("Boom")));
        }

        [Test]
        public void LogDebug_LogsVerboseMessage()
        {
            Assert.DoesNotThrow(() => _logger.LogDebug("Debugging {0}", "Session"));
        }

        [Test]
        public void MultipleLogs_DoNotConflict()
        {
            _logger.LogInfo("Starting");
            _logger.LogDebug("Step 1");
            _logger.LogError("Failed step {0}", 2);
            Assert.Pass();
        }

        [Test]
        public void NullArguments_AreHandled()
        {
            Assert.DoesNotThrow(() => _logger.LogInfo("null args test", null));
        }

        [Test]
        public void StructuredData_IsLogged()
        {
            var obj = new { Name = "Vijay", Success = true };
            _logger.LogInfo("Data {@obj}", obj);
            Assert.Pass();
        }

        [Test]
        public void LoggerFlush_DoesNotThrow()
        {
            Assert.DoesNotThrow(() => Log.CloseAndFlush());
        }

        [Test]
        public void LoggerSupportsFileWrite()
        {
            // Use a unique temp folder for isolation
            var tempDir = Path.Combine(Path.GetTempPath(), $"SerilogTest_{Guid.NewGuid()}");
            Directory.CreateDirectory(tempDir);

            var logPath = Path.Combine(tempDir, "testlog.txt");

            // Configure Serilog to write to this path
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .WriteTo.File(logPath, rollingInterval: RollingInterval.Infinite)
                .CreateLogger();

            var logger = new SerilogLoggerService();
            logger.LogInfo("Writing to file...");
                        
            Log.CloseAndFlush();

            // Wait briefly to ensure file system catches up
            Thread.Sleep(100);

            Assert.That(File.Exists(logPath), Is.True, $"Expected log file at: {logPath}");

            var content = File.ReadAllText(logPath);
            Assert.That(content, Does.Contain("Writing to file"));
        }

        [Test]
        public void LoggerCanFormatMultipleValues()
        {
            _logger.LogInfo("Values: {0}, {1}", 1, "X");
            Assert.Pass();
        }

        [Test]
        public void LoggingDoesNotInterruptExecution()
        {
            for (int i = 0; i < 5; i++)
            {
                _logger.LogDebug("Ping {0}", i);
            }
            Assert.Pass();
        }
    }


}
