﻿using CodeLineCounterApp.Models;

namespace CodeLineCounterApp.Tests
{
    internal class LoadConfigdto : AppSettings
    {
        public List<string> IncludedExtensions { get; set; }
        public List<string> ExcludedPaths { get; set; }
    }
}